#ifndef   DISPLAY
#define   DISPLAY

#include <stdconst.h>

//
// existing declarations 
//

// add a call to print time as HH:MM:SS
printtime(UBYTE hh, UBYTE mm, UBYTE ss);

// add anything else you need for debugging

#endif
