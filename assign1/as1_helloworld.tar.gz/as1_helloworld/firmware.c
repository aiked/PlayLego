#include <stdlib.h>
#include <assert.h>

void hello_world(void) {

}

int main(void)
{
	hello_world();
	return 0;
}
